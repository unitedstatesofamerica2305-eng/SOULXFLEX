import { SellerData, ApiResponse } from '../types';

/**
 * Normalizes incoming data from different API structures into a consistent SellerData object.
 */
export const normalizeSellerData = (data: any): SellerData | null => {
  if (!data) return null;

  // Helper to find value case-insensitively
  const getVal = (obj: any, keys: string[]) => {
    for (const key of keys) {
      if (obj[key] !== undefined && obj[key] !== null && obj[key] !== '') return obj[key];
      // Check lowercase version
      const lowerKey = key.toLowerCase();
      const foundKey = Object.keys(obj).find(k => k.toLowerCase() === lowerKey);
      if (foundKey && obj[foundKey]) return obj[foundKey];
    }
    return "";
  };

  // If the data itself looks like a seller record (has name/mobile)
  const isDirectRecord = (obj: any) => {
    const mobile = getVal(obj, ['mobile', 'number', 'phone', 'Mobile', 'Number']);
    const name = getVal(obj, ['name', 'Name', 'customer_name', 'owner_name']);
    return mobile || name;
  };

  if (!isDirectRecord(data)) {
    return null;
  }

  return {
    id: data.id || Math.floor(Math.random() * 10000),
    mobile: getVal(data, ['mobile', 'number', 'phone', 'Mobile']),
    name: getVal(data, ['name', 'Name', 'customer_name', 'owner_name', 'consumer_name']),
    father_name: getVal(data, ['father_name', 'FatherName', 'guardian_name']),
    address: getVal(data, ['address', 'Address', 'billing_address', 'installation_address']),
    alt_mobile: getVal(data, ['alt_mobile', 'alternate_number', 'alt_phone']),
    circle: getVal(data, ['circle', 'state', 'Circle']),
    id_number: getVal(data, ['id_number', 'aadhar', 'id_proof']),
    email: getVal(data, ['email', 'Email', 'mail_id']),
  };
};

/**
 * Parses the raw API response to extract the result object(s).
 */
export const parseApiResponse = (response: any): SellerData[] => {
  if (!response) return [];

  let rawResults: any[] = [];

  // Check standard "result" or "data" fields
  if (Array.isArray(response.result)) rawResults = response.result;
  else if (Array.isArray(response.data)) rawResults = response.data;
  else if (response.result && typeof response.result === 'object') rawResults = [response.result];
  else if (response.data && typeof response.data === 'object') rawResults = [response.data];
  // Check if root object is the data
  else if (typeof response === 'object') rawResults = [response];

  // Normalize each item
  return rawResults
    .map(normalizeSellerData)
    .filter((item): item is SellerData => item !== null);
};