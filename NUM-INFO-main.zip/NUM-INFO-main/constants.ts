export const API_BASE_URL = 'https://niloy-number-info-api.vercel.app/api/seller';
export const DEFAULT_API_KEY = 'Niloy'; // In production, use import.meta.env.VITE_API_KEY

// If true, uses the local /api/proxy route (for Vercel). 
// If false, tries direct call (may fail due to CORS).
export const USE_PROXY = false;