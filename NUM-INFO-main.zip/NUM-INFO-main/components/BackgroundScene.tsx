import React, { useRef } from 'react';
import { Canvas, useFrame } from '@react-three/fiber';
import { Stars, PerspectiveCamera, Sparkles } from '@react-three/drei';
import * as THREE from 'three';

// Add type definitions for R3F elements
// Augment React's JSX namespace (typical for React 18+)
declare module 'react' {
  namespace JSX {
    interface IntrinsicElements {
      mesh: any;
      planeGeometry: any;
      meshStandardMaterial: any;
      ambientLight: any;
      pointLight: any;
      fog: any;
    }
  }
}

// Fallback for global JSX namespace
declare global {
  namespace JSX {
    interface IntrinsicElements {
      mesh: any;
      planeGeometry: any;
      meshStandardMaterial: any;
      ambientLight: any;
      pointLight: any;
      fog: any;
    }
  }
}

const Rig = () => {
  useFrame((state) => {
    // Parallax effect: Camera moves slightly opposite to mouse to create depth
    state.camera.position.x = THREE.MathUtils.lerp(state.camera.position.x, state.pointer.x * 2, 0.05);
    state.camera.position.y = THREE.MathUtils.lerp(state.camera.position.y, state.pointer.y * 1, 0.05);
    state.camera.lookAt(0, 0, 0);
  });
  return null;
}

const FloatingGrid = ({ position, rotation, color }: { position: [number, number, number], rotation: [number, number, number], color: string }) => {
  const mesh = useRef<THREE.Mesh>(null);
  
  useFrame((state) => {
    if (mesh.current) {
      // Organic wave movement
      mesh.current.position.z = position[2] + Math.sin(state.clock.elapsedTime * 0.5) * 0.5;
      mesh.current.rotation.z = rotation[2] + Math.cos(state.clock.elapsedTime * 0.2) * 0.05;
    }
  });

  return (
    <mesh ref={mesh} position={position} rotation={rotation}>
      <planeGeometry args={[60, 60, 50, 50]} />
      <meshStandardMaterial 
        color={color} 
        wireframe 
        transparent 
        opacity={0.2} 
        emissive={color}
        emissiveIntensity={0.8}
        side={THREE.DoubleSide}
      />
    </mesh>
  );
};

export default function BackgroundScene() {
  return (
    <div className="fixed inset-0 w-full h-full -z-10 bg-[#020202]">
      <Canvas gl={{ antialias: true, toneMapping: THREE.ACESFilmicToneMapping }}>
        <PerspectiveCamera makeDefault position={[0, 0, 14]} />
        <Rig />
        
        <ambientLight intensity={0.2} />
        
        {/* Dynamic lights */}
        <pointLight position={[15, 15, 10]} intensity={3} color="#00f3ff" distance={40} />
        <pointLight position={[-15, -15, 10]} intensity={3} color="#bc13fe" distance={40} />

        {/* Stars background */}
        <Stars radius={100} depth={50} count={6000} factor={4} saturation={0} fade speed={1} />
        
        {/* Floating Particles for Depth */}
        <Sparkles count={150} scale={15} size={3} speed={0.4} opacity={0.6} color="#00f3ff" />
        <Sparkles count={100} scale={20} size={5} speed={0.2} opacity={0.4} color="#bc13fe" position={[0, 0, 5]} />

        {/* Cyber Grids */}
        <FloatingGrid position={[0, -6, -5]} rotation={[-1.5, 0, 0]} color="#bc13fe" />
        <FloatingGrid position={[0, 10, -10]} rotation={[1.6, 0, 0]} color="#00f3ff" />
        
        <fog attach="fog" args={['#020202', 10, 40]} />
      </Canvas>
    </div>
  );
}