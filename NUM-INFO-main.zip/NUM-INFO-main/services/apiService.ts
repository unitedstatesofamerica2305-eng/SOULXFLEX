import { API_BASE_URL, DEFAULT_API_KEY, USE_PROXY } from '../constants';
import { ApiResponse } from '../types';

export async function fetchSellerData(mobile: string): Promise<{ status: number, data: ApiResponse, time: number }> {
  // Cast import.meta to any to resolve "Property 'env' does not exist on type 'ImportMeta'"
  // Note: When using PROXY, we prefer the server to handle the key for security.
  const clientSideKey = (import.meta as any).env?.VITE_API_KEY || DEFAULT_API_KEY;
  const startTime = performance.now();

  let finalStatus = 0;
  let finalData: ApiResponse | null = null;

  // Detect if we are running on localhost or production to help decide default proxy behavior
  const isProduction = (import.meta as any).env?.PROD;
  
  // Use proxy if explicitly set, or fall back to direct if not
  // You can toggle this boolean in constants.ts
  const shouldUseProxy = USE_PROXY; 

  try {
    let url: string;

    if (shouldUseProxy) {
      // PROXY MODE: Do NOT send the key. The proxy (Vercel/Netlify) will inject it from env vars.
      // We check if we are on Netlify or Vercel based on the path usually, but standardizing on /api/proxy
      // works for Vercel. For Netlify, we added a redirect in netlify.toml from /api/proxy -> /.netlify/functions/proxy
      url = `/api/proxy?mobile=${encodeURIComponent(mobile)}`;
    } else {
      // DIRECT MODE: We must send the key.
      url = `${API_BASE_URL}?mobile=${encodeURIComponent(mobile)}&key=${encodeURIComponent(clientSideKey)}`;
    }

    const response = await fetch(url);
    finalStatus = response.status;
    
    // Attempt to parse JSON
    try {
      finalData = await response.json();
    } catch (e) {
      finalData = { success: false, message: "Invalid JSON response from server" };
    }

  } catch (error) {
    console.warn("Primary fetch failed, attempting fallback...", error);
    
    // Fallback Logic:
    // If we tried Direct and it failed (CORS), try Proxy.
    // If we tried Proxy and it failed, we are stuck.
    if (!shouldUseProxy) {
        try {
            // Fallback to proxy without key (server injects it)
            const proxyUrl = `/api/proxy?mobile=${encodeURIComponent(mobile)}`;
            const response = await fetch(proxyUrl);
            finalStatus = response.status;
            finalData = await response.json();
        } catch (proxyError) {
            console.error("Proxy fallback failed", proxyError);
            finalStatus = 0;
            finalData = { success: false, message: "Connection Failed: Could not reach API." };
        }
    } else {
        finalStatus = 0;
        finalData = { success: false, message: "Connection Failed." };
    }
  }

  const endTime = performance.now();
  
  if (!finalData) {
      finalData = { success: false, message: "Unknown error occurred" };
  }

  return {
    status: finalStatus,
    data: finalData,
    time: endTime - startTime
  };
}