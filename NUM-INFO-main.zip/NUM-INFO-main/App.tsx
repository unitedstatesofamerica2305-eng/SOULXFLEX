import React, { useState, useRef } from 'react';
import { SearchForm } from './components/SearchForm';
import { ResultCard } from './components/ResultCard';
import { fetchSellerData } from './services/apiService';
import { ApiResponse, SellerData } from './types';
import { parseApiResponse } from './utils/dataUtils';
import { motion, AnimatePresence } from 'framer-motion';

function App() {
  const [loading, setLoading] = useState(false);
  const [results, setResults] = useState<SellerData[]>([]);
  const [error, setError] = useState<string | null>(null);
  const containerRef = useRef<HTMLDivElement>(null);

  const handleSearch = async (mobile: string) => {
    setLoading(true);
    setResults([]);
    setError(null);

    try {
      const { status, data } = await fetchSellerData(mobile);
      
      // Even if status is 200, the API might return an error message in the body
      // We parse the data first to see if we found valid records
      const parsedResults = parseApiResponse(data);

      if (parsedResults.length > 0) {
        setResults(parsedResults);
      } else {
        // If no results found, check for specific error messages or status codes
        if (status !== 200) {
           setError('Failed to fetch data. Server Error.');
        } else if (data && data.message) {
           setError(data.message);
        } else {
           setError('No records found for this number.');
        }
      }
    } catch (err) {
      setError('An unexpected error occurred.');
    } finally {
      setLoading(false);
    }
  };

  // Subtle Tilt Effect Logic
  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!containerRef.current) return;
    
    const { clientX, clientY, currentTarget } = e;
    const { width, height } = currentTarget.getBoundingClientRect();
    
    // Calculate rotation (-1 to 1 range), reduced intensity
    const xPct = (clientX / width - 0.5);
    const yPct = (clientY / height - 0.5);

    // Update CSS variables for the tilt
    containerRef.current.style.setProperty('--rx', `${yPct * -2}deg`); // Tilt X
    containerRef.current.style.setProperty('--ry', `${xPct * 2}deg`);  // Tilt Y
  };

  const handleMouseLeave = () => {
    if (containerRef.current) {
      containerRef.current.style.setProperty('--rx', '0deg');
      containerRef.current.style.setProperty('--ry', '0deg');
    }
  }

  return (
    <div 
      className="relative min-h-screen w-full overflow-hidden text-slate-200 selection:bg-soft-sky selection:text-white"
      onMouseMove={handleMouseMove}
      onMouseLeave={handleMouseLeave}
    >
      {/* Soft Gradient Background */}
      <div className="fixed inset-0 w-full h-full -z-10 bg-[conic-gradient(at_top_right,_var(--tw-gradient-stops))] from-slate-900 via-slate-950 to-gray-900"></div>
      
      {/* Ambient Glows */}
      <div className="fixed top-[-10%] left-[-10%] w-[50%] h-[50%] bg-soft-sky/10 rounded-full blur-[120px] pointer-events-none" />
      <div className="fixed bottom-[-10%] right-[-10%] w-[50%] h-[50%] bg-soft-indigo/10 rounded-full blur-[120px] pointer-events-none" />

      <style>{`
        .tilt-card {
          transform: rotateX(var(--rx, 0deg)) rotateY(var(--ry, 0deg));
          transition: transform 0.2s cubic-bezier(0.2, 0, 0.2, 1);
          will-change: transform;
          transform-style: preserve-3d;
        }
      `}</style>

      {/* Main Content with Tilt Effect */}
      <div 
        ref={containerRef}
        className="relative z-10 container mx-auto px-4 py-12 flex flex-col items-center min-h-screen tilt-card perspective-[2000px]"
      >
        
        {/* Header */}
        <motion.header 
          initial={{ opacity: 0, y: -20, filter: 'blur(5px)' }}
          animate={{ opacity: 1, y: 0, filter: 'blur(0px)' }}
          transition={{ duration: 0.8, ease: "easeOut" }}
          className="text-center mb-12 transform-style-3d"
        >
          <div className="relative inline-block mb-3">
            <h1 className="text-5xl md:text-7xl font-bold tracking-tight text-transparent bg-clip-text bg-gradient-to-br from-white via-slate-200 to-slate-500">
              CODEWITH<span className="text-soft-sky font-light">-FLEXYxSOUL</span>
            </h1>
          </div>
          <p className="text-slate-400 text-sm md:text-base font-medium tracking-[0.3em] uppercase opacity-80">
            Number To Info
          </p>
        </motion.header>

        {/* Search Input */}
        <div className="w-full flex justify-center transform-style-3d translate-z-10">
           <SearchForm onSearch={handleSearch} isLoading={loading} />
        </div>

        {/* Content Area */}
        <div className="w-full max-w-2xl mt-12 pb-20 transform-style-3d translate-z-5">
          <AnimatePresence mode="wait">
            
            {/* Loading State */}
            {loading && (
              <motion.div
                key="loading"
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.95, filter: 'blur(10px)' }}
                className="flex flex-col items-center justify-center py-12"
              >
                <div className="relative">
                  <div className="w-16 h-16 border-2 border-slate-700/50 border-t-soft-sky rounded-full animate-spin" />
                </div>
                <p className="mt-6 text-soft-sky/80 font-mono text-xs tracking-[0.2em] uppercase">
                  Processing Request...
                </p>
              </motion.div>
            )}

            {/* Error State */}
            {error && !loading && (
              <motion.div
                key="error"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                className="bg-red-500/5 border border-red-500/20 p-6 rounded-2xl text-center backdrop-blur-md relative overflow-hidden max-w-lg mx-auto"
              >
                 <div className="relative z-10">
                    <p className="text-red-400 font-bold tracking-wider uppercase mb-2 text-sm">Action Failed</p>
                    <p className="text-red-200/80 text-sm">{error}</p>
                 </div>
              </motion.div>
            )}

            {/* Success State */}
            {!loading && results.length > 0 && (
              <div key="results" className="w-full">
                {results.map((item, idx) => (
                  <ResultCard key={item.id || idx} data={item} index={idx} />
                ))}
              </div>
            )}
            
          </AnimatePresence>
        </div>

        {/* Footer */}
        <footer className="mt-auto py-6 text-center text-slate-600 text-[10px] font-mono uppercase tracking-widest transform-style-3d translate-z-5">
           <span className="text-soft-sky/40">Secure Connection</span> • Data Encrypted
        </footer>
      </div>
    </div>
  );
}

export default App;