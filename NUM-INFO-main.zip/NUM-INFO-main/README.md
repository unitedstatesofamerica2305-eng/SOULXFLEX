# NUM-INFO | NeonLookup

A futuristic, high-performance web interface for looking up seller information. Built with React, TypeScript, Tailwind CSS, and Framer Motion.

## Features
- **Soft Glass UI**: Premium dark aesthetic with glassmorphism and soft glows.
- **3D Tilt Interactions**: UI elements react to mouse movement.
- **Responsive Design**: Fully optimized for mobile and desktop.
- **Serverless Proxy**: Secure API communication via Vercel/Netlify functions (bypasses CORS).

## Local Development

1. **Install Dependencies**
   ```bash
   npm install
   ```

2. **Start Dev Server**
   ```bash
   npm run dev
   ```
   Open [http://localhost:5173](http://localhost:5173) in your browser.

3. **Environment Variables (Optional)**
   Create a `.env` file in the root:
   ```
   VITE_API_KEY=Niloy
   ```

## Deployment

### Option 1: Vercel (Recommended)

1. Push this code to a GitHub repository.
2. Go to [Vercel](https://vercel.com) and click **"Add New Project"**.
3. Import your repository.
4. **Build Settings**: Vercel detects Vite automatically.
   - Framework Preset: `Vite`
   - Build Command: `npm run build`
   - Output Directory: `dist`
5. **Environment Variables**:
   - Go to Settings > Environment Variables.
   - Add `API_KEY` with your secret key (Default: `Niloy`).
6. Click **Deploy**.

*Note: The `api/proxy.ts` file is automatically detected by Vercel as a Serverless Edge Function.*

### Option 2: Netlify

1. Push this code to a GitHub repository.
2. Go to [Netlify](https://netlify.com) and click **"Add new site"** > **"Import an existing project"**.
3. Select your repository.
4. **Build Settings**:
   - Build command: `npm run build`
   - Publish directory: `dist`
5. **Environment Variables**:
   - Go to Site Settings > Environment Variables.
   - Add `API_KEY` with your secret key.
6. Click **Deploy**.

*Note: The `netlify.toml` file configures the redirect from `/api/proxy` to the function located in `netlify/functions/proxy.mts`.*

## Configuration

### Proxy vs Direct
By default, the app can try to call the API directly. However, due to CORS restrictions on many APIs, a proxy is recommended.

In `src/constants.ts`, you can toggle:
```typescript
export const USE_PROXY = true; // Set to true to force proxy usage
```
Even if set to `false`, the `apiService.ts` includes a fallback mechanism: if the direct call fails, it automatically attempts to route through `/api/proxy`.

### Security
- **Client-Side**: The app does not hardcode the API key in the `fetch` call when using the proxy.
- **Server-Side**: The proxy functions (`api/proxy.ts` for Vercel, `netlify/functions/proxy.mts` for Netlify) inject the key from server-side Environment Variables.

## Tech Stack
- **Framework**: React 19 + Vite
- **Language**: TypeScript
- **Styling**: Tailwind CSS
- **Animation**: Framer Motion
- **Deployment**: Vercel / Netlify Edge Functions