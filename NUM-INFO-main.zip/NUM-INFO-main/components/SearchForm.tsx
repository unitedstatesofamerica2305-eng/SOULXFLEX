import React, { useState } from 'react';
import { motion } from 'framer-motion';

interface SearchFormProps {
  onSearch: (mobile: string) => void;
  isLoading: boolean;
}

export const SearchForm: React.FC<SearchFormProps> = ({ onSearch, isLoading }) => {
  const [mobile, setMobile] = useState('');
  const [error, setError] = useState('');
  const [isFocused, setIsFocused] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!/^\d{10}$/.test(mobile)) {
      setError('Please enter a valid 10-digit number');
      return;
    }
    setError('');
    onSearch(mobile);
  };

  return (
    <motion.form 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6, delay: 0.3 }}
      onSubmit={handleSubmit} 
      className="w-full max-w-md mx-auto relative z-20"
    >
      <div className={`relative transition-all duration-500 ${isFocused ? 'scale-[1.02]' : 'scale-100'}`}>
        
        {/* Soft Shadow Behind */}
        <div className={`absolute -inset-4 bg-soft-sky/20 rounded-2xl blur-xl transition-opacity duration-500 ${isFocused ? 'opacity-40' : 'opacity-0'}`}></div>

        <div className={`relative flex items-center bg-white/5 backdrop-blur-xl rounded-xl border transition-colors duration-300 overflow-hidden ${isFocused ? 'border-soft-sky/30 bg-white/10' : 'border-white/10'}`}>
          <div className="pl-4 pr-3 text-slate-400">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
            </svg>
          </div>
          
          <input
            type="text"
            value={mobile}
            onFocus={() => setIsFocused(true)}
            onBlur={() => setIsFocused(false)}
            onChange={(e) => {
              const val = e.target.value.replace(/\D/g, '').slice(0, 10);
              setMobile(val);
              if (val.length === 10) setError('');
            }}
            placeholder="Search mobile number..."
            className="w-full px-2 py-4 bg-transparent text-white placeholder-slate-500 focus:outline-none text-lg font-medium tracking-wide"
            disabled={isLoading}
          />
          
          <div className="pr-1.5">
            <motion.button
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              type="submit"
              disabled={isLoading || mobile.length !== 10}
              className={`h-9 px-5 rounded-lg font-semibold text-xs transition-all duration-300 flex items-center justify-center tracking-wider uppercase ${
                isLoading || mobile.length !== 10
                  ? 'bg-slate-800/50 text-slate-600 cursor-not-allowed'
                  : 'bg-soft-sky text-slate-900 hover:bg-white hover:text-black shadow-lg shadow-soft-sky/20'
              }`}
            >
              {isLoading ? (
                <div className="w-4 h-4 border-2 border-slate-900/30 border-t-slate-900 rounded-full animate-spin" />
              ) : (
                'Search'
              )}
            </motion.button>
          </div>
        </div>
      </div>
      
      {/* Validation Message */}
      <div className="h-6 mt-2 pl-2 flex items-center">
        {error && (
          <motion.p 
            initial={{ opacity: 0, x: -5 }}
            animate={{ opacity: 1, x: 0 }}
            className="text-red-400 text-xs font-medium"
          >
            {error}
          </motion.p>
        )}
      </div>
    </motion.form>
  );
};