import React from 'react';
import { motion } from 'framer-motion';
import { SellerData } from '../types';

interface ResultCardProps {
  data: SellerData;
  index: number;
}

export const ResultCard: React.FC<ResultCardProps> = ({ data, index }) => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 40 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6, delay: index * 0.1, ease: "easeOut" }}
      className="relative w-full max-w-lg mx-auto mt-8 group"
    >
      {/* Glass Card Container */}
      <div className="relative bg-white/5 backdrop-blur-2xl rounded-2xl p-0 overflow-hidden border border-white/10 shadow-glass transition-all duration-500 group-hover:bg-white/10 group-hover:border-white/20">
        
        {/* Subtle Gradient Overlay */}
        <div className="absolute top-0 right-0 w-64 h-64 bg-soft-sky/5 rounded-full blur-3xl pointer-events-none transform translate-x-1/2 -translate-y-1/2" />
        
        <div className="relative z-10 p-8">
          {/* Header */}
          <div className="flex items-center justify-between mb-8 border-b border-white/5 pb-6">
            <div>
              <label className="text-soft-sky text-[10px] font-bold tracking-widest uppercase mb-1.5 block opacity-90">
                Verified Identity
              </label>
              <h2 className="text-2xl font-bold text-white tracking-tight">
                {data.name || "Unknown Name"}
              </h2>
            </div>
            <div className="w-10 h-10 rounded-full border border-soft-sky/30 flex items-center justify-center bg-soft-sky/10 text-soft-sky">
               <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                 <path fillRule="evenodd" d="M10 9a3 3 0 100-6 3 3 0 000 6zm-7 9a7 7 0 1114 0H3z" clipRule="evenodd" />
               </svg>
            </div>
          </div>

          <div className="space-y-8">
            {/* Primary Mobile */}
            <div className="relative">
              <label className="text-slate-400 text-[10px] font-semibold tracking-widest uppercase block mb-1">
                Primary Contact
              </label>
              <div className="flex items-baseline gap-2">
                <span className="text-3xl font-light text-white tracking-wide font-mono">
                  {data.mobile}
                </span>
                <div className="h-2 w-2 rounded-full bg-emerald-400 shadow-[0_0_8px_rgba(52,211,153,0.5)]" />
              </div>
            </div>

            {/* Grid Info */}
            <div className="grid grid-cols-2 gap-y-6 gap-x-4">
               <div>
                  <label className="text-slate-500 text-[10px] font-bold tracking-widest uppercase block mb-1.5">Alt Contact</label>
                  <p className={`text-lg font-mono ${data.alt_mobile ? 'text-soft-indigo' : 'text-slate-600'}`}>
                    {data.alt_mobile || "N/A"}
                  </p>
               </div>
               <div>
                  <label className="text-slate-500 text-[10px] font-bold tracking-widest uppercase block mb-1.5">Guardian</label>
                  <p className="text-lg text-slate-300 font-medium">
                    {data.father_name || "N/A"}
                  </p>
               </div>
            </div>

            {/* Address */}
            <div className="bg-slate-900/40 rounded-xl p-4 border border-white/5">
              <label className="text-slate-500 text-[10px] font-bold tracking-widest uppercase block mb-2">Registered Address</label>
              <p className="text-base text-slate-300 leading-relaxed">
                {data.address || "Address not available"}
              </p>
            </div>

            {/* Grid: Circle & ID */}
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="text-slate-500 text-[10px] font-bold tracking-widest uppercase block mb-1.5">SIM CARD</label>
                <p className="text-sm font-semibold text-white tracking-wide">{data.circle || "Unknown"}</p>
              </div>
               <div>
                <label className="text-slate-500 text-[10px] font-bold tracking-widest uppercase block mb-1.5">AADHAR NUMBER</label>
                <p className="text-sm font-mono text-slate-400">{data.id_number || "N/A"}</p>
              </div>
            </div>

            {/* Email */}
            <div className="pt-6 border-t border-white/5">
              <label className="text-slate-500 text-[10px] font-bold tracking-widest uppercase block mb-1.5">Email Address</label>
              <p className={`text-lg font-mono truncate ${data.email ? 'text-white' : 'text-slate-600'}`}>
                {data.email || "Email not available IN Database"}
              </p>
            </div>

          </div>
        </div>
      </div>
    </motion.div>
  );
};