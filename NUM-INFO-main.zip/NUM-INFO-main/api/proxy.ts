// Vercel Edge Function
export const config = {
  runtime: 'edge',
};

export default async function handler(request: Request) {
  const url = new URL(request.url);
  const mobile = url.searchParams.get('mobile');
  
  // SECURE: Get key from server environment variable, fallback to query param (for dev), then default.
  // In Vercel dashboard, set API_KEY in Settings > Environment Variables.
  const apiKey = process.env.API_KEY || url.searchParams.get('key') || 'Niloy';

  if (!mobile) {
    return new Response(JSON.stringify({ success: false, message: 'Missing mobile parameter' }), {
      status: 400,
      headers: { 'content-type': 'application/json' },
    });
  }

  // Construct target URL
  const targetUrl = `https://niloy-number-info-api.vercel.app/api/seller?mobile=${encodeURIComponent(mobile)}&key=${encodeURIComponent(apiKey)}`;

  try {
    const apiRes = await fetch(targetUrl);
    const data = await apiRes.json();

    return new Response(JSON.stringify(data), {
      status: apiRes.status,
      headers: {
        'content-type': 'application/json',
        // CORS headers to allow the frontend to call this proxy
        'Access-Control-Allow-Origin': '*', 
        'Access-Control-Allow-Methods': 'GET, OPTIONS',
        'Cache-Control': 's-maxage=60, stale-while-revalidate',
      },
    });
  } catch (error) {
    return new Response(JSON.stringify({ success: false, message: 'Proxy Error: Could not reach upstream API' }), {
      status: 500,
      headers: { 
        'content-type': 'application/json',
        'Access-Control-Allow-Origin': '*'
      },
    });
  }
}