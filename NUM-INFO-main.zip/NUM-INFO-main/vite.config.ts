import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

// https://vitejs.dev/config/
export default defineConfig({
  plugins: [react()],
  server: {
    proxy: {
      '/api/proxy': {
        target: 'https://niloy-number-info-api.vercel.app',
        changeOrigin: true,
        rewrite: (path) => {
          // Extract mobile number from the request path query params
          const url = new URL('http://dummy' + path);
          const mobile = url.searchParams.get('mobile');
          const key = 'Niloy'; // Hardcoded for local dev proxy
          
          // Rewrite to the real API endpoint
          return `/api/seller?mobile=${mobile}&key=${key}`;
        },
      },
    },
  },
});