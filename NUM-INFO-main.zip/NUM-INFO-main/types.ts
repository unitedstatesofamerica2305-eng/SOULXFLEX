export interface SellerData {
  id: number;
  mobile: string;
  name: string;
  father_name: string;
  address: string;
  alt_mobile: string;
  circle: string;
  id_number: string;
  email: string;
}

export interface ApiResponse {
  success?: boolean;
  result?: SellerData[] | SellerData | any; // Allow relaxed types for parsing
  data?: SellerData[] | SellerData | any;   // Some APIs use 'data' instead of 'result'
  message?: string; 
  [key: string]: any; // Allow arbitrary keys for flexible API support
}

export interface FetchResult {
  data: ApiResponse | null;
  loading: boolean;
  error: string | null;
  status: number | null;
  time: number;
}